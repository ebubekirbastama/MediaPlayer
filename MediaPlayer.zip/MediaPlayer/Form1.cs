﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediaPlayer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        OpenFileDialog op;
        private void Form1_Load(object sender, EventArgs e)
        {
            media.Visible = false;

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radioButton1.Checked == true)
                {
                    op = new OpenFileDialog();
                    op.Filter = "Media File(*.mpg,*.dat,*.avi,*.wmv,*.wav,*.mp3)|*.wav;*.mp3;*.mpg;*.dat;*.avi;*.wmv";
                    if (op.ShowDialog() == DialogResult.OK)
                    {
                        media.URL = op.FileName.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Müzik Seçilmedi..");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void media_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            if (media.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                progressBar1.Maximum = (int)media.Ctlcontrols.currentItem.duration;
                timer1.Start();
            }
            else if (media.playState == WMPLib.WMPPlayState.wmppsPaused)
            {
                timer1.Stop();
            }
            else if (media.playState == WMPLib.WMPPlayState.wmppsStopped)
            {
                timer1.Stop();
                progressBar1.Value = 0;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (media.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                progressBar1.Value = (int)media.Ctlcontrols.currentPosition;
            }

        }
    }
}
